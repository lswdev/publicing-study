let a=10, b=15;
function addFunction() {  
  return a+b;
}

function multFunction() {  
  return a*b;
}

export default addFunction;