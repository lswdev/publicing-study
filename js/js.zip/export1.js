const WordsEl = 'name';
const WordsEl2 = 'name2';

export { WordsEl, WordsEl2 };